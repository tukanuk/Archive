public interface NumberFormatter 
{
    String format(int n);
}