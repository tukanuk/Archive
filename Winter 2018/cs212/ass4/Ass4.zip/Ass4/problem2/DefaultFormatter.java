public class DefaultFormatter implements NumberFormatter
{
    public String format(int n)
    {
        return Integer.toString(n);
    }
}