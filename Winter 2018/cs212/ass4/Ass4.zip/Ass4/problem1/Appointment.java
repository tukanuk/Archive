public class Appointment
{
    /* Private instance variables */
    String description;

    

    /* Constructor */

    public Appointment()
    {
        description = "";
    }

    /* Methods */
    
    public int occursOn(int day, int month, int year)
    {
        return -5;
    }
}